### CODE REPRESENTATION ###
# --- Imports --- #
from OSAcc_ValidationUtils_Lib.ServerActions import AttributeValidation_CreatedAndUpdated
from OSAcc_WorkOrders_CS.ServerActions import WorkOrder_CreateOrUpdate, WorkOrderTask_Delete, CustomerFeedback_Delete, Task_Delete, Task_SetIsActive, WorkOrder_Delete, WorkOrderTask_CreateOrUpdate, CustomerNote_Delete, CustomerNote_CreateOrUpdate, CustomerFeedback_CreateOrUpdate, WorkOrder_SetIsActive
from SiteProperties import TenantId, TenantName
####
# --- Datamodel --- #
@dataclass
class Task:
        """Entity that holds the records of Tasks."""
        Id: TaskId
        TaskCode: str
        Description: str
        TaskServiceTypeId: TaskServiceType
        TaskTypeId: TaskType
        CreatedBy: UserId
        CreatedOn: datetime.datetime
        UpdatedBy: UserId
        UpdatedOn: datetime.datetime
        IsActive: bool
####
# --- Flow --- #
var1 = IServerAction(Name=Task_CreateOrUpdate, InputParameters={"Task": Task}, OutputParameters={"TaskId": TaskId})
var2 = IStartNode()
var1.add_subflow(var2)
var3 = <extra_id_0>
var2.sequence = var3
var4 = IRaiseExceptionNode(ExceptionMessage=<LITERAL>)
var3.undefined = var4
####

### LABEL ###
IIfNode(Condition=((((Trim(Task.TaskCode) = NullTextIdentifier()) or (Task.TaskServiceTypeId = NullIdentifier())) or (Task.TaskTypeId = NullIdentifier())) or (Trim(Task.Description) = NullTextIdentifier())))
